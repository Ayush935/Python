
"""if __name__ == "__main__":
    print("This is the main module")  # This will not run
    result = []
    for i in [7]*10:
        result.append(i)

    print(result)
    print(2**2**2)"""


# Single THreaded 
# it took time 13.5933256149292

"""from multiprocessing import Pool
from time import time

def calculate(x):
        return (x**x**8)

if __name__ == "__main__":
    currentTime = time()
    print(time())

    result = []
    for i in [7]*10:
        result.append(calculate(i))

    print(time()-currentTime)"""


# Muytiple Threading 
# it took time 2.337414503097534

from multiprocessing import Pool
from time import time

def calculate(x):
    return (x**x**8)

if __name__ == "__main__":
    currentTime = time()

    pool = Pool(processes=10)    # starts 10 worker processes
    result = pool.map(calculate,[7]*10)
    print(time()-currentTime)
    pool.close()


"""
import library
from multiprocessing import Pool

Start worker process
pool = Pool(processes=10)

use processess to execute functions
pool.map(your_fuction,[your_input_array])

"""