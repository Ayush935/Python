import re
myString = "15:49 is time, also 125:45 works! emailid : ayush.ar@kpit.com "

MyStringNum = re.findall("[0-9]",myString)
print(MyStringNum)

MyStringTime = re.findall("[0-9]{2}:[0-9]{2}",myString)
print(MyStringTime)

MyStringTime2 = re.findall("[0-9]{2,}:[0-9]{2}",myString)
print(MyStringTime2)

string = re.sub("[^a-zA-Z\ ]","",myString)
print(string)

MailId = re.findall("[a-zA-Z0-9._-]{1,20}@[a-zA-Z0-9._-]{1,20}.com",myString)
print(MailId)


