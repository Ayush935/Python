import os

def current_directory():
    cwd = os.getcwd()
    print(cwd)

def file_path(filename):
    path = os.path.abspath((filename))
    print(path)

current_directory()
filename = "Sample.txt"
file_path(filename)


