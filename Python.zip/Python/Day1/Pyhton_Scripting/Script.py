# Python Scripting

import os

def current_directory():
    cwd = os.getcwd()
    print(cwd)

def file_path(filename):
    path = os.path.abspath(filename)
    print(path)

current_directory()
file_path("sample.txt")