from os import path

def create_file(dest):
    if (path.isfile(dest)):
        file = open(dest,'w')
        file.write("Welcome to scripting")
        file.close()

dest = "/home/kpit/Desktop/Python/Day1/Sample.txt"
create_file(dest)

print("file created")
