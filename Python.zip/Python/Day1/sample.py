"""import sys

print("Hello")

print('H' not in "Hello")

print(sys.version)

x,y = map(int,input().split())
print(x,y)"""

"""
x = lambda a,b : a*b
print(x(45,56))


class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def __str__(self):
        return f"{self.name}({self.age})"

    def myfunc(self):
        print("My name is "+ self.name)


p1 = Person("john",26)
p1.name = "Ayush"

print(p1)
p1.myfunc()
# print(p1.age)

"""


# Python Scripting

import os

def current_directory():
    cwd = os.getcwd()
    print(cwd)

def file_path(filename):
    path = os.path.abspath(filename)
    print(path)

current_directory()
file_path("sample.txt")