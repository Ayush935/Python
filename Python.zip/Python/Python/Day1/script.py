
name_of_customer = input("Name of the customer : ")
bill_amount = float(input("Bill amount : "))
tip_amount = float(input("Percentage of bill amount : "))

total_amount = bill_amount + (bill_amount * (tip_amount / 100))

print(f"tottal amount of {name_of_customer} is {total_amount} ")

