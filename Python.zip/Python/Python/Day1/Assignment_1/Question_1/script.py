"""
1. Greeting Message

Write a program that asks for the user’s name and prints a greeting message like “Hello, [Name]!” 
    
"""

name_of_user = input("Name of the user : ")
print(f"Hello, [{name_of_user}]!")