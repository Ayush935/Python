"""
6. Swap two variables

Write a program that takes two integer inputs from the user and swaps their values, print the swapped values. Example, set a = 1, b = 3, print that now a = 3, b = 1. Try swapping without using any extra variables. 

"""

a = int(input("Enter Value a : "))
b = int(input("Enter Value b : "))

a = a + b
b = a - b
a = a - b

print(f"After swapping a = {a} and b = {b} ")