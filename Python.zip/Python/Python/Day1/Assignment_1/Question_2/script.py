""" 
2. Circle Area Calculator

Prompt the user for a radius and calculate the area of a circle using the formula π × r^2 (use 3.14 for π). 

"""

radius = float(input("Enter the radius of the circle : "))
area = 3.14 * (radius ** 2)

print(f"Area of the circle is : {area}")