"""
3. Simple Interest Calculator

Write a program that asks for principal, rate, and time from the user, then calculates and prints the simple interest using the formula: SI = (principal * rate * time) / 100.

"""

principal = float(input("Enter Principal Amount : "))
rate = float(input("Enter Rate of interest : "))
time = float(input("Enter Time in years : "))

Simple_Inetrest = (principal * rate * time) / 100

print(f"Simple Interset is : {Simple_Inetrest}")
