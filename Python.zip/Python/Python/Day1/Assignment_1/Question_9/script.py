""" 
9. Days to weeks

Write a program to take number of days from user as input and convert it to weeks and remaining days. Example, 10 days = 1 week 3 days. (Hint: look up ‘//’ and ‘%’ operators in python)

"""

days = int(input("Enter number of days : "))
weeks = days/7
print(f"days to weeks ", weeks)