""" 
10. Divisibility

Write a program that checks whether a number is divisible by both 3 and 5.

· Give number “n” as an input from the console

· If the number is divisible by both 3 and 5, print:

o “Number n divisible by both 3 and 5”

"""

def test_divisibility(num):
    if num%3==0 and num%5==0:
        return "Number n is divisible by both 3 and 5"
    else:
        return "Number n is not divisible by both 3 and 5"
    

number = int(input("Enter number n :"))
print("Divisibilty : ",test_divisibility(number))  
