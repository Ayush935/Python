""" 
4. Data Type Checker

Prompt the user to enter something, then determine and print its data type (e.g., integer, float, string).

"""

value = input("Enter something : ")
print("Type of the input is : ", type(value))  