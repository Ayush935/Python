""" 
5. Temperature Converter

Write a program that converts a temperature from Fahrenheit to Celsius. Prompt the user for the temperature in Fahrenheit and use the formula: C = (F - 32) / 1.8. 

"""

temperature_in_fahrenheit = float(input("Enter the temperature in fahrenheit : "))
temperature_in_celsius = (temperature_in_fahrenheit - 32) / 18
print(f"{temperature_in_fahrenheit}°F is equal to {temperature_in_celsius}°C")  