""" 
7. Calculate BMI

Write a program that takes weight in grams and height in centimeters and calculates their BMI. BMI = weight in kg / (height in meters * height in meters) 

"""

def calculate_bmi (weight, height):
    return (weight/1000) / (height/100)**2
    

weight_in_grams = float(input("Enter weight in grams :"))
height_in_centimeters = float(input("Enter height in centimeters :"))
bmi = calculate_bmi(weight_in_grams,height_in_centimeters)

print(f"BMI is : {bmi}")

