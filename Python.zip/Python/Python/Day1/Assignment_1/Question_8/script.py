""" 
8. Currency converter

Write a program to convert rupees to euros, assume 1 euro = 90 rupees. 

"""

rupees = float(input("Enter the amount of rupees: "))
euro = rupees / 90

print(f"Rupees {rupees} is equal to {euro} euros")