# from scapy.all import rdpcap
 
# packets = rdpcap('/home/kpit/Documents/req_res_2.pcapng')
 
# for packet in packets:
#     print(packet.summary())
    
# from scapy.all import rdpcap, IP, UDP


# packets = rdpcap('/home/kpit/Documents/req_res_2.pcapng')


# for packet in packets:
 
#     if packet.haslayer(IP) and packet.haslayer(UDP):
  
#         udp_payload = packet[UDP].payload
        
       
#         if udp_payload and udp_payload.name == "SOME/IP":
#             print("SOME/IP Packet:")
#             print(packet.summary())
#             print(udp_payload.show())

# from scapy.all import rdpcap, IP, UDP

# # Load the pcapng file
# packets = rdpcap('/home/kpit/Documents/req_res_2.pcapng')

# # Loop through each packet in the pcap
# for packet in packets:
#     # Check if the packet has IP and UDP layers
#     if packet.haslayer(IP) and packet.haslayer(UDP):
#         # Get the UDP payload
#         udp_payload = packet[UDP].payload
        
#         # Check if the payload is a SOME/IP message
#         if udp_payload and udp_payload.name == "SOME/IP":
#             # Print details about the SOME/IP packet
#             print("SOME/IP Packet:")
#             print(packet.summary())
#             print(udp_payload.show())

#             # Extracting SOME/IP request and response details
#             if udp_payload.fields.get("service_id"):
#                 service_id = udp_payload.fields["service_id"]
#                 method_id = udp_payload.fields.get("method_id", "N/A")
#                 request_id = udp_payload.fields.get("request_id", "N/A")
#                 payload = udp_payload.load  # Raw payload data

#                 print(f"Service ID: {service_id}")
#                 print(f"Method ID: {method_id}")
#                 print(f"Request ID: {request_id}")
#                 print(f"Payload: {payload.hex()}")  # Print payload in hex format

# # Note: Make sure to adjust the field names according to your specific SOME/IP implementation and Scapy's capabilities.

# from scapy.all import rdpcap, IP, UDP

# # Load the pcapng file
# packets = rdpcap('/home/kpit/Documents/req_res_2.pcapng')
# print(f"Total packets loaded: {len(packets)}")

# # Loop through each packet in the pcap
# for packet in packets:
#     print(packet.summary())
#     if packet.haslayer(IP) and packet.haslayer(UDP):
#         print("Packet has IP and UDP layers.")
        
#         # Get the UDP payload
#         udp_payload = packet[UDP].payload
        
#         if udp_payload:
#             print("UDP Payload:")
#             print(udp_payload.show())
#             print(f"Raw UDP Payload: {udp_payload.load.hex()}")

#             # Check for SOME/IP fields (you may need to parse this manually)
#             # Example: Check if the payload starts with SOME/IP header bytes
#             if udp_payload.load.startswith(b'\x00\x00'):  # Placeholder for SOME/IP header check
#                 print("Detected SOME/IP message.")
#                 # Parse fields here based on SOME/IP specification
#                 # ...

# # Note: Adjust the checks based on the actual structure of your SOME/IP messages.


# from scapy.all import *
# import sys

# # Define the SOME/IP packet structure


# class SOMEIP(Packet):
#     fields_desc = [
#         ByteField("message_id", 0),
#         ByteField("service_id", 0),
#         ByteField("method_id", 0),
#         ShortField("length", 0),
#         ByteField("payload", 0)
#     ]

# bind_layers(UDP, SOMEIP, dport=30490)  # Adjust the port as necessary

# def extract_someip_requests_responses(pcap_file):
#     packets = rdpcap(pcap_file)
#     requests = []
#     responses = []

#     for packet in packets:
#         if packet.haslayer(SOMEIP):
#             someip_packet = packet.getlayer(SOMEIP)

#             # Assuming message_id is used to distinguish between requests and responses
#             if someip_packet.message_id & 0x80:  # Example: Check if the high bit is set (indicating a response)
#                 responses.append(someip_packet)
#             else:
#                 requests.append(someip_packet)

#     return requests, responses

# if __name__ == "__main__":
#     if len(sys.argv) != 2:
#         print("Usage: python extract_someip.py <pcap_file>")
#         sys.exit(1)

#     pcap_file = sys.argv[1]
#     requests, responses = extract_someip_requests_responses(pcap_file)

#     print("SOME/IP Requests:")
#     for req in requests:
#         print(f"Service ID: {req.service_id}, Method ID: {req.method_id}, Payload: {req.payload}")

#     print("\nSOME/IP Responses:")
#     for res in responses:
#         print(f"Service ID: {res.service_id}, Method ID: {res.method_id}, Payload: {res.payload}")


# from scapy.all import rdpcap, UDP
# from someipy.serialization import SomeIpPayload

# # Step 1: Load the PCAP file
# pcap_file = '/home/kpit/Documents/req_res_2.pcapng'  # Replace with your PCAP file path
# packets = rdpcap(pcap_file)

# # Step 2: Extract SOME/IP requests and responses
# some_ip_messages = []

# for packet in packets:
#     # Check if the packet has a UDP layer and filter by SOME/IP port
#     if packet.haslayer(UDP) and (packet[UDP].dport == 30490 or packet[UDP].sport == 30490):
#         # Extract the payload (SOME/IP message)
#         payload = packet[UDP].payload.load
#         try:
#             # Deserialize the SOME/IP message
#             some_ip_message = SomeIpPayload.deserialize(payload)
#             some_ip_messages.append(some_ip_message)
#             print(f"Extracted SOME/IP message: {some_ip_message}")
#         except Exception as e:
#             print(f"Failed to deserialize payload: {e}")

# # Step 3: Process the extracted messages (for demonstration)
# for message in some_ip_messages:
#     # Print the details of the SOME/IP message
#     print(f"Message ID: {message.message_id}")
#     print(f"Service ID: {message.service_id}")
#     print(f"Method ID: {message.method_id}")
#     print(f"Client ID: {message.client_id}")
#     print(f"Payload: {message.payload}")

# import dpkt
# import socket
# import struct
 
# # Function to parse SOME/IP headers
# def parse_someip(data):
#     try:
#         # SOME/IP header fields
#         msg_id = struct.unpack(">I", data[:4])[0]  # First 4 bytes
#         length = struct.unpack(">I", data[4:8])[0]  # Next 4 bytes
#         req_id = struct.unpack(">I", data[8:12])[0]  # Next 4 bytes
#         proto_ver = data[12]  # Next 1 byte
#         intf_ver = data[13]   # Next 1 byte
#         msg_type = data[14]   # Next 1 byte
#         ret_code = data[15]   # Next 1 byte
 
#         # SOME/IP payload
#         payload = data[16:16 + length]
 
#         return {
#             "Message ID": msg_id,
#             "Length": length,
#             "Request ID": req_id,
#             "Protocol Version": proto_ver,
#             "Interface Version": intf_ver,
#             "Message Type": msg_type,
#             "Return Code": ret_code,
#             "Payload": payload,
#         }
#     except Exception as e:
#         print(f"Failed to parse SOME/IP: {e}")
#         return None
 
# # Function to read PCAP and extract SOME/IP packets
# def extract_someip_requests_responses(file_name):
#     requests = []
#     responses = []
    
    
#     with open(file_name, 'rb') as f:
#         pcap = dpkt.pcap.Reader(f)
#         for timestamp, raw_data in pcap:
#             eth = dpkt.ethernet.Ethernet(raw_data)
            
#             if isinstance(eth.data, dpkt.ip.IP):
#                 ip = eth.data
 
#                 # Check for UDP or TCP (common for SOME/IP)
#                 if isinstance(ip.data, (dpkt.tcp.TCP, dpkt.udp.UDP)):
#                     transport = ip.data
#                     someip_data = transport.data
 
#                     # Parse SOME/IP packet
#                     someip_packet = parse_someip(someip_data)
#                     if someip_packet:
#                         if someip_packet["Message Type"] == 0x00:  # REQUEST
#                             requests.append((timestamp, someip_packet))
#                         elif someip_packet["Message Type"] == 0x80:  # RESPONSE
#                             responses.append((timestamp, someip_packet))
 
#     return requests, responses
 
# # Example usage
# requests, responses = extract_someip_requests_responses("req_res_2.pcapng")
 
# print("SOME/IP Requests:")
# for timestamp, packet in requests:
#     print(f"Timestamp: {timestamp}, Packet: {packet}")
 
# print("\nSOME/IP Responses:")
# for timestamp, packet in responses:
#     print(f"Timestamp: {timestamp}, Packet: {packet}")


import dpkt
import socket
import struct
 
# Function to parse SOME/IP headers
def parse_someip(data):
    try:
        # SOME/IP header fields
        msg_id = struct.unpack(">I", data[:4])[0]  # First 4 bytes
        length = struct.unpack(">I", data[4:8])[0]  # Next 4 bytes
        req_id = struct.unpack(">I", data[8:12])[0]  # Next 4 bytes
        proto_ver = data[12]  # Next 1 byte
        intf_ver = data[13]   # Next 1 byte
        msg_type = data[14]   # Next 1 byte
        ret_code = data[15]   # Next 1 byte
 
        # SOME/IP payload
        payload = data[16:16 + length]
 
        return {
            "Message ID": msg_id,
            "Length": length,
            "Request ID": req_id,
            "Protocol Version": proto_ver,
            "Interface Version": intf_ver,
            "Message Type": msg_type,
            "Return Code": ret_code,
            "Payload": payload,
        }
    except Exception as e:
        print(f"Failed to parse SOME/IP: {e}")
        return None
 
# Function to read PCAP and extract SOME/IP packets
def extract_someip_requests_responses(file_name):
    requests = []
    responses = []
    request_timestamps = {}
 
    with open(file_name, 'rb') as f:
        pcap = dpkt.pcap.Reader(f)
        for timestamp, raw_data in pcap:
            eth = dpkt.ethernet.Ethernet(raw_data)
 
            if isinstance(eth.data, dpkt.ip.IP):
                ip = eth.data
 
                # Get source and destination IP addresses
                src_ip = socket.inet_ntoa(ip.src)
                dst_ip = socket.inet_ntoa(ip.dst)
 
                # Check for UDP or TCP (common for SOME/IP)
                if isinstance(ip.data, (dpkt.tcp.TCP, dpkt.udp.UDP)):
                    transport = ip.data
                    someip_data = transport.data
 
                    # Parse SOME/IP packet
                    someip_packet = parse_someip(someip_data)
                    if someip_packet:
                        if someip_packet["Message Type"] == 0x00:  # REQUEST
                            requests.append((timestamp, src_ip, dst_ip, someip_packet))
                            # Store the timestamp for this request ID
                            request_timestamps[someip_packet["Request ID"]] = timestamp
                        elif someip_packet["Message Type"] == 0x80:  # RESPONSE
                            responses.append((timestamp, src_ip, dst_ip, someip_packet))
                            # Calculate the timestamp difference
                            req_timestamp = request_timestamps.get(someip_packet["Request ID"])
                            if req_timestamp is not None:
                                time_diff = (timestamp - req_timestamp) * 1000  # Convert to milliseconds
                                # Store the time difference with the request for printing later
                                for i in range(len(requests)):
                                    if requests[i][3]["Request ID"] == someip_packet["Request ID"]:
                                        requests[i] = (*requests[i], time_diff)  # Append time_diff to the request
                                del request_timestamps[someip_packet["Request ID"]]  # Remove matched request
 
    return requests, responses
 
# Example usage
requests, responses = extract_someip_requests_responses("req_res_2.pcapng")
 
# print("SOME/IP Requests from pcap file:")
# for timestamp, src_ip, dst_ip, packet, *time_diff in requests:
#     print(f"Timestamp: {timestamp}, Source IP: {src_ip}, Destination IP: {dst_ip}, Packet: {packet}")
#     if time_diff:
#         print(f"    Time Diff for Request ID {packet['Request ID']}: {time_diff[0]:.2f} ms")
 
# print("\nSOME/IP Responses for pcap file:")
# for timestamp, src_ip, dst_ip, packet in responses:
#     print(f"Timestamp: {timestamp}, Source IP: {src_ip}, Destination IP: {dst_ip}, Packet: {packet}")
 
print("SOME/IP Requests from pcap file:")
for timestamp, src_ip, dst_ip, packet, *time_diff in requests:
    print("Timestamp:", timestamp)
    print("Source IP:", src_ip)
    print("Destination IP:", dst_ip)
    print("Packet:", packet)
    if time_diff:
        print(f"    Time Diff for Request ID {packet['Request ID']}: {time_diff[0]:.2f} ms")
    print()  # Add a blank line for better readability

print("\nSOME/IP Responses for pcap file:")
for timestamp, src_ip, dst_ip, packet in responses:
    print("Timestamp:", timestamp)
    print("Source IP:", src_ip)
    print("Destination IP:", dst_ip)
    print("Packet:", packet)
    print()  # Add a blank line for better readability