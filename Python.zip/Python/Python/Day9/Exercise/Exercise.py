# import threading

# def print_odd_numbers(num):
#     for i in range(1,num+1):
#         if i%2!=0:
#             print("Even number : ",i)
            
# def print_even_numbers(num):
#     for i in range(1,num+1):
#         if i%2==0:
#             print("Odd number : ",i)
            
# number = int(input("Enter number : "))
# thread1 = threading.Thread(target=print_odd_numbers,args=(number,))
# thread2 = threading.Thread(target=print_even_numbers,args=(number,))

# thread1.start()
# thread2.start()
# thread1.join()
# thread2.join()


# import multiprocessing
# import math

# def factorial(num):
#     return math.factorial(num)

# if __name__ == "__main__":
#     numbers = list(map(int, input("Enter the list of numbers: ").split()))

#     with multiprocessing.Pool() as pool:
#         result = pool.map(factorial, numbers)
    
#     for number, fact in zip(numbers, result):
#         print(f"Factorial of {number} is {fact}")

# import threading
# import queue
# import time
# import random


# BUFFER_SIZE = 5

# buffer = queue.Queue(BUFFER_SIZE)

# def producer(producer_id):
#     while True:
#         item = random.rand
#         print(f'Producer {producer_id} produced: {item}')
#         time.sleep(random.uniform(0.1, 1))  

# def consumer(consumer_id):
#     while True:
#         item = buffer.get()  
#         print(f'Consumer {consumer_id} consumed: {item}')
#         buffer.task_done()  
#         time.sleep(random.uniform(0.1, 1))  


# def main():
#     num_producers = 2
#     num_consumers = 3

#     producers = []
#     consumers = []


#     for i in range(num_producers):
#         prod_thread = threading.Thread(target=producer, args=(i,))
#         producers.append(prod_thread)
#         prod_thread.start()

#     for i in range(num_consumers):
#         consumer_thread = threading.Thread(target=consumer, args=(i,))
#         consumers.append(consumer_thread)
#         consumer_thread.start()

   
#     for prod_thread in producers:
#         prod_thread.join()
#     for consumer_thread in consumers:
#         consumer_thread.join()

# if __name__ == "__main__":
#     main()

# import time
# import threading
# import multiprocessing


# def cpu_bound_task(n):
#     return sum(i * i for i in range(n))

# def run_with_threading(n, num_threads):
#     threads = []
#     for _ in range(num_threads):
#         thread = threading.Thread(target=cpu_bound_task, args=(n,))
#         threads.append(thread)
#         thread.start()
    
#     for thread in threads:
#         thread.join()

# def run_with_multiprocessing(n, num_processes):
#     processes = []
#     for _ in range(num_processes):
#         process = multiprocessing.Process(target=cpu_bound_task, args=(n,))
#         processes.append(process)
#         process.start()
    
#     for process in processes:
#         process.join()

# if __name__ == "__main__":
#     n = 10**6  
#     num_threads = 4  
#     num_processes = 4  

  
#     start_time = time.time()
#     run_with_threading(n, num_threads)
#     threading_time = time.time() - start_time
#     print(f"Threading execution time: {threading_time:.4f} seconds")

#     start_time = time.time()
#     run_with_multiprocessing(n, num_processes)
#     multiprocessing_time = time.time() - start_time
#     print(f"Multiprocessing execution time: {multiprocessing_time:.4f} seconds")


# import concurrent.futures
# import time
# import random

# def task(n):
#     print(f"Task {n}: Starting")
   
#     time.sleep(random.uniform(1, 3))
#     print(f"Task {n}: Completed")
#     return f"Result of task {n}"

# def main():
  
#     tasks = range(10)  

#     with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
      
#         future_to_task = {executor.submit(task, n): n for n in tasks}

       
#         for future in concurrent.futures.as_completed(future_to_task):
#             task_number = future_to_task[future]
#             try:
#                 result = future.result()
#                 print(f"Task {task_number} completed with result: {result}")
#             except Exception as exc:
#                 print(f"Task {task_number} generated an exception: {exc}")

# if __name__ == "__main__":
#     main()

# import asyncio
# import random

# async def producer(queue):
#     for _ in range(10):
#         item = random.randint(1, 100)
#         await queue.put(item)
#         print(f'Produced {item}')
#         await asyncio.sleep(random.random())

# async def consumer(queue):
#     while True:
#         item = await queue.get()
#         print(f'Consumed {item}')
#         queue.task_done()
#         await asyncio.sleep(random.random())

# async def main():
#     queue = asyncio.Queue()
#     prod = asyncio.create_task(producer(queue))
#     cons = asyncio.create_task(consumer(queue))
#     await prod
#     await queue.join()
#     cons.cancel()

# asyncio.run(main())

# import asyncio
# import random

# async def async_task(name, duration):
#     print(f"Task {name}: started, will take {duration} seconds.")
#     await asyncio.sleep(duration)
#     print(f"Task {name}: completed.")

# async def main():
#     tasks = [async_task(f"Task-{i+1}", random.randint(1, 5)) for i in range(3)]
#     await asyncio.gather(*tasks)

# if __name__ == "__main__":
#     asyncio.run(main())

# import asyncio
# import random

# async def worker(name, duration):
#     print(f"Task {name}: Starting, will run for {duration} seconds.")
#     try:
#         await asyncio.sleep(duration)
#         print(f"Task {name}: Completed successfully.")
#     except asyncio.CancelledError:
#         print(f"Task {name}: Cancelled!")

# async def main():
#     tasks = [asyncio.create_task(worker(f"Worker-{i}", random.randint(1, 5))) for i in range(5)]
#     await asyncio.sleep(2)
#     for i in range(2):
#         print(f"Cancelling Task {i}")
#         tasks[i].cancel()
#     await asyncio.gather(*tasks, return_exceptions=True)

# if __name__ == "__main__":
#     asyncio.run(main())


# from functools import reduce

# numbers = [1, 2, 3, 4, 5]

# product = reduce(lambda x, y: x * y, numbers)

# print("The product of all numbers in the list is:", product)


import random
import time

def retry(retries):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for attempt in range(retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    print(f"Attempt {attempt + 1} failed: {e}")
                    if attempt < retries - 1:
                        time.sleep(1)  
            raise Exception("All attempts failed")
        return wrapper
    return decorator

@retry(retries=3)  
def unreliable_function():
    if random.choice([True, False]):
        print("Success!")
    else:
        print("Failing...")
        raise Exception("An error occurred")

try:
    unreliable_function()
except Exception as e:
    print(e)