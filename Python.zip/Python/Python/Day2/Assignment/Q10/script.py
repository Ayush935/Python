number = int(input("Enter the number : "))

num = str(number)
length = len(num)
sum = 0

for i in num:
    sum += (int(i)**length)
    
if number==sum:
    print(number,"is an armstrong number")
else:
    print(number,"is not an armstrong number")
    
