string = input("Enter the string : ")
string.lower()

letters = 0
numbers = 0
other_characters = 0

for i in string:
    if i.isalpha():
        letters += 1
    elif i.isdigit():
        numbers += 1
    else:
        other_characters += 1
        
print("Number of letters : ",letters)
print("Number of numbers : ",numbers)
print("Number of other characters : ",other_characters)
        