number = int(input("Enter number of elements: "))

for i in range(1,number) :
    for j in range(i) :
        print("*",end=" ")
    print()
       
for i in range(number-1,-1,-1) :
    for j in range(i) :
        print("*",end=" ")
    print()