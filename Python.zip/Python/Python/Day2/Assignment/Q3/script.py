num = input("Enter the number : ")
result = 0

for i in num :
    result = max(result,int(i))
    
print("Maximum number", result)