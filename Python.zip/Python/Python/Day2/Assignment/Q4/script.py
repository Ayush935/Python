string = input("Enter the string: ")
length_of_string = len(string)
string_b = ""

for i in range(length_of_string-1,-1,-1) :
    string_b = string_b + string[i]
    
string = string_b

print("Reverse string is : ",string_b)
    