year_one = int(input("Enter the year of the first event : "))
year_two = int(input("Enter the year of the second event : "))

for i in range(year_one,year_two):
    if i%4 == 0 :
        print(i,"is a leap year")