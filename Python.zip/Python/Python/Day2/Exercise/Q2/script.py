num = int(input("Enter number : "))
ans = 1
for i in range(num):
    ans = ans*(i+1)
    
print(f"Factorial of {num} is {ans}")