secret_num = 25
guess_num = int(input("Guess the secret number between 0 and 50 : "))

while guess_num != secret_num:
    if guess_num>=0 and guess_num<=15:
        print("Too low")
    elif guess_num>15 and guess_num<=30:
        print("near")
    elif guess_num>30 and guess_num<=45:
        print("Too high")
    guess_num = int(input("Try again : "))   
        
print("Correct")