password = input("Enter password : ")
a,b = 0,0

if len(password)>=8:
    password = password.lower()
    for i in password:
         if 'a' <= i <= 'z':  
            a += 1
         elif '0' <= i <= '9':  
            b += 1
    
    if a>0 and b>0:
        print("Password is following the conditions")
else :
    print("Password not following the conditions")