input = input("Enter String : ")

input.lower()
vowels = "aeiou"

vowels_values = 0
consonants_values = 0

for i in input:
    if i.isalpha():
        if i in vowels:
            vowels_values += 1
        else :
            consonants_values += 1
            
            
print("Number of Vowels : ", vowels_values)
print("Number of Consonants : ", consonants_values)