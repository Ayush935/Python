number = int(input("Enter the number between 0 and 100 : "))

if number >= 90 and number <= 100:
    print("A")
elif number>=80 and number <= 89:
    print("B")
elif number>=70 and number <= 79:
    print("C")
elif number>=60 and number <= 69:
    print("D")
else :
    print("F")  # This will print F if the number is less than 60