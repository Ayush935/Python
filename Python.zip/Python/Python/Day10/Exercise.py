# from typing import List, Tuple, Dict, Literal


# def tuples_to_dict(pairs: List[Tuple[str, int]]) -> Dict[str, int]:
#     return dict(pairs)


# def sort_numbers(nums: List[int], order: Literal['asc', 'desc']) -> List[int]:
#     return sorted(nums) if order == 'asc' else sorted(nums, reverse=True)


# if __name__ == "__main__":
   
#     example_pairs = [("apple", 1), ("banana", 2), ("cherry", 3)]
#     result = tuples_to_dict(example_pairs)
#     print("Dictionary:", result)  

   
#     numbers = [5, 2, 9, 1, 5, 6]
#     print("Sorted Ascending:", sort_numbers(numbers, 'asc'))   
#     print("Sorted Descending:", sort_numbers(numbers, 'desc')) 

from typing import List, Literal

def sort_numbers(nums: List[int], order: Literal['asc', 'desc']) -> List[int]:
   
  
    if order == 'asc':
        return sorted(nums)
    elif order == 'desc':
        return sorted(nums, reverse=True)
    else:
        raise ValueError("order asc or desc")


if __name__ == "__main__":
    numbers = [5, 2, 9, 1, 5, 6]
    
    sort_asc = sort_numbers(numbers, 'asc')
    print("Sort asc:", sort_asc) 
    sort_desc = sort_numbers(numbers, 'desc')
    print("Sort dsc:", sort_desc)  