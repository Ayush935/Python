# 1. Implement a generic Pair class that stores two values of any type. Add methods to:
#     Get the values as a tuple.
#     Compare two Pair objects for equality.

# from typing import Any,Generic,Tuple,TypeVar

# T = TypeVar('T')

# class Pair(Generic[T]):
#     def __init__(self,first: T,second : T):
#         self.first = first
#         self.second = second
        
#     def get_values(self) -> Tuple[T,T]:
#         return (self.first,self.second)
    
# obj_pair = Pair(1,2)
# print(obj_pair.get_values())

from typing import TypeVar, Generic, List, Tuple, Dict, Literal
from functools import partial, lru_cache
import time
# from pydantic import BaseModel

# Generic type variables
# T1 = TypeVar('T1')
# T2 = TypeVar('T2')

# Task 1: Implement a generic Pair class
# class Pair(Generic[T1, T2]):
#     def __init__(self, first: T1, second: T2):
#         self.first = first
#         self.second = second

#     def get_values(self) -> Tuple[T1, T2]:
#         return (self.first, self.second)

#     def __eq__(self, other: object) -> bool:
#         if isinstance(other, Pair):
#             return (self.first, self.second) == (other.first, other.second)
#         return False

# Task 2: Function to Convert List of Tuples to Dictionary
def tuples_to_dict(tuples_list: List[Tuple[str, int]]) -> Dict[str, int]:
    return {key: value for key, value in tuples_list}

result = tuples_to_dict([('apple', 1), ('banana', 2), ('orange', 3)])
print(result)

# Task 3: Function to Sort Numbers with Literal Type Annotations
# from typing import List, Literal

# def sort_numbers(nums: List[int], order: Literal["asc", "desc"]) -> List[int]:
   
#     if order == "asc":
#         return sorted(nums)
#     elif order == "desc":
#         return sorted(nums, reverse=True)
#     else:
#         raise ValueError("Order must be 'asc' or 'desc'.")

# if __name__ == "__main__":
#     numbers = [5, 2, 9, 1, 5, 6]
    
#     sorted_asc = sort_numbers(numbers, "asc")
#     print("Sorted Ascending:", sorted_asc)
    
#     sorted_desc = sort_numbers(numbers, "desc")
#     print("Sorted Descending:", sorted_desc)

# # Task 4: Program to Read Integers from a File with Error Handling
# from typing import List, Literal

# def sort_numbers(nums: List[float], order: Literal['asc', 'desc']) -> List[float]:
#     if order == 'asc':
#         return sorted(nums)
#     elif order == 'desc':
#         return sorted(nums, reverse=True)
#     else:
#         raise ValueError("Order must be either 'asc' or 'desc'")

# # Example usage
# numbers = [5, 2, 9, 1, 5, 6]
# sorted_asc = sort_numbers(numbers, 'asc')
# sorted_desc = sort_numbers(numbers, 'desc')

# print("Sorted Ascending:", sorted_asc)
# print("Sorted Descending:", sorted_desc)

# # Task 5: Custom Exception Class for Invalid Age
# class InvalidAgeError(Exception):
  
#     def __init__(self, age):
#         self.age = age
#         super().__init__(f"Invalid age: {age}. Age must be between 0 and 150.")

# def check_age(age: int):
#     if age < 0 or age > 150:
#         raise InvalidAgeError(age)
#     return f"Age {age} is valid."


# try:
#     print(check_age(25))  
#     print(check_age(-1))  
# except InvalidAgeError as e:
#     print(e)

# try:
#     print(check_age(151))  
# except InvalidAgeError as e:
#     print(e)

# # Task 6: Using Partial to Create Customized Versions of `pow`
# from functools import partial

# square = partial(pow, exponent=2)  
# cube = partial(pow, exponent=3)   

# if __name__ == "__main__":
#     number = 5
#     print(f"The square of {number} is: {number ** 2}")  
#     print(f"The cube of {number} is: {number ** 3}")   
# # Task 7: Specialized Version of `print` Using `partial`
# from functools import partial


# def create_file_printer(file):
#     return partial(print, file=file, end='\n')


# if __name__ == "__main__":
   
#     with open('output.txt', 'w') as f:
#         file_print = create_file_printer(f)
        
       
#         file_print("Hello, World!")
#         file_print("This will be written to the file.")
#         file_print("Each message is followed by a newline.")

# # Task 8: Modify `int()` with Partial for Binary Parsing
# from functools import partial


# binary_int = partial(int, base=2)


# if __name__ == "__main__":
   
#     binary_string_1 = '1010'  
#     binary_string_2 = '1111' 

 
#     result_1 = binary_int(binary_string_1)
#     result_2 = binary_int(binary_string_2)

#     print(f"The integer value of binary string '{binary_string_1}' is: {result_1}")  
#     print(f"The integer value of binary string '{binary_string_2}' is: {result_2}")  
    
# # Task 9: Program to Memoize Fibonacci Function Using `lru_cache`
# import time
# from functools import lru_cache


# def fibonacci_no_cache(n):
#     if n <= 1:
#         return n
#     return fibonacci_no_cache(n - 1) + fibonacci_no_cache(n - 2)


# @lru_cache(maxsize=None)  
# def fibonacci_with_cache(n):
#     if n <= 1:
#         return n
#     return fibonacci_with_cache(n - 1) + fibonacci_with_cache(n - 2)


# def measure_execution_time(func, n):
#     start_time = time.time()
#     result = func(n)
#     end_time = time.time()
#     return result, end_time - start_time

# if __name__ == "__main__":
#     n = 35  

  
#     print(f"Calculating Fibonacci({n}) without cache...")
#     result_no_cache, time_no_cache = measure_execution_time(fibonacci_no_cache, n)
#     print(f"Result: {result_no_cache}, Time taken: {time_no_cache:.6f} seconds")

#     print(f"\nCalculating Fibonacci({n}) with cache...")
#     result_with_cache, time_with_cache = measure_execution_time(fibonacci_with_cache, n)
#     print(f"Result: {result_with_cache}, Time taken: {time_with_cache:.6f} seconds")
# # Task 10: Basics of Pydantic
# # class User(BaseModel):
# #     id: int
# #     name: str
# #     age: int

# # # Example usage of Pydantic
# # def example_pydantic() -> None:
# #     user = User(id=1, name='John Doe', age=30)
# #     print("Pydantic User:", user)

# # # Main execution
# # if __name__ == "__main__":
# #     # Task 1 Example
# #     pair1 = Pair(1, "apple")
# #     pair2 =
# Pydantic is a data validation and settings management library for Python, primarily used for validating and parsing data using Python type annotations. It is widely used in applications that require strict data validation, such as web applications and APIs, especially in conjunction with frameworks like FastAPI.



