"""

From the object created in q1 call methods from all classes it inherits from.
    
"""

class Parent:
    
    def __init__(self):
        pass
    
    def function(self):
        print("Parent class function executed")
        
class ChildA(Parent):
    
    def function(self):
        print("childA class function executed")
        
class ChildB(Parent):
    
    def function(self):
        print("childA class function executed")
        
class ChildC(ChildA, ChildB):
    
    def call_functions(self):
        
        Parent.function(self)
        ChildA.function(self)
        ChildB.function(self)
        

obj1 = ChildC()
obj1.call_functions()