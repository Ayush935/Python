"""
Create a base class and two child classes that inherit from it, 
all of the above classes should have a function with same name but different print statements. 
Now create a class that inherits from both the child classes and call the implemented function on its object, 
see which function is executed.    

"""

class Parent:
    
    def __init__(self):
        pass
    
    def function(self):
        print("Parent class function executed")
        
class ChildA(Parent):
    
    def function(self):
        print("childA class function")
        
class ChildB(Parent):
    
    def function(self):
        print("childA class function")
        
class ChildC(ChildA, ChildB):
    
        pass

obj1 = ChildC()
obj1.function()