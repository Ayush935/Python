def list_all_subclass_names(cls):
   
    subclasses = cls.__subclasses__()  
    subclass_names = [subclass.__name__ for subclass in subclasses]  

   
    for subclass in subclasses:
        subclass_names.extend(list_all_subclass_names(subclass))

    return subclass_names


class Parent:
    
    def __init__(self):
        pass
    
    def function(self):
        print("Parent class function executed")
        
class ChildA(Parent):
    
    def function(self):
        print("childA class function executed")
        
class ChildB(Parent):
    
    def function(self):
        print("childA class function executed")
        
class ChildC(ChildA, ChildB):
    
    def call_functions(self):
        
        Parent.function(self)
        ChildA.function(self)
        ChildB.function(self)


print(list_all_subclass_names(Parent))  