import json

class JSONSerializable:
    def to_json(self):
        data_dict = {}
        for attr in ['name', 'age']:
            if hasattr(self, attr):
                data_dict[attr] = self.__getattribute__(attr)
        return json.dumps(data_dict)

class XMLSerializable:
    def to_xml(self):
        xml_parts = []
        for attr in ['name', 'age']:
            if hasattr(self, attr):
                value = self.__getattribute__(attr)
                xml_parts.append(f"<{attr}>{value}</{attr}>")
        return ''.join(xml_parts)

class Data(JSONSerializable, XMLSerializable):
    def __init__(self, name, age):
        self.name = name
        self.age = age

data = Data(name="Alice", age=25)
print(data.to_json())
print(data.to_xml())