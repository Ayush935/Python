"""
Overload the + operator for a class point (which has x, y co-ords as attributes) to add the co-ords individually, x = x1+x2, y = y1+y2. When an object of the class is printed it should print the distance of the point from the origin.
    
"""

class point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __add__(self,other):
        return point(self.x+other.x, self.y+other.y)
    
    def distance_from_origin(self):
        return (self.x**2 + self.y**2)**0.5
    
    def __str__(self):
        return f"Distance from origin: {self.distance_from_origin()}"

obj1 = point(1,2)
obj2 = point(3,4)
obj3 = obj1 + obj2
print(obj3.x)
print(obj3.y)
print(obj3) 