"""
Write a class that inherits from the class in q.2 and modify it so that len of object of this child class returns count of consonants in the string attribute

"""

class VowelsCounter:
    def __init__(self, string):
        self.string = string
        
    def __len__(self):
        string = self.string.lower()
        vowels = 'aeiou'
        return sum(1 for char in string if char in vowels)
    
    def __str__(self):
        return f"String: {self.string}, Vowels: {len(self)}"
    
class ConsonantsCounter(VowelsCounter):
    
    def __len__(self):
        string = self.string.lower()
        vowels = 'aeiou'
        return sum(1 for char in string if char not in vowels)
    
    def __str__(self):
        return f"String: {self.string}, Consonants: {len(self)}"

string = input("Enter the string : ")
obj1 = ConsonantsCounter(string)
print(obj1)  