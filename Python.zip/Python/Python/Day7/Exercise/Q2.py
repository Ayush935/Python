"""
Write a python class with a __len__ method to count the vowels in a string attribute.

"""

class VowelCounter:
    def __init__(self,string):
        self.string = string
        
    def __len__(self):
        string = self.string.lower()
        vowels = 'aeiou'
        return sum(1 for char in string if char in vowels)
    
    def __str__(self):
        return f"Vowel Counter: {self.string}"
    
string = input("Enter the string : ")
obj1 = VowelCounter(string)
print(f"Length of vowels in the string: {len(obj1)}")