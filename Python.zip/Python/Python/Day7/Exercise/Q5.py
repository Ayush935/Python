"""
Write code to get the names of child classes in the parent class, implement it as a class method.

"""

class Parent:
    @classmethod
    def get_child_classes(cls):
        return cls.__subclasses__()


class ChildA(Parent):
    pass

class ChildB(Parent):
    pass

class ChildC(ChildA):
    pass


if __name__ == "__main__":
    child_classes = Parent.get_child_classes()
    print("Child classes of Parent:", [child.__name__ for child in child_classes])