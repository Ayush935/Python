"""

Implement a class with @classmethod and @staticmethod.

"""



class MyClass:
    
    voter_age = 18
    list_of_instances = []
    
    def __init__(self, age):
        self.age = age
        MyClass.list_of_instances.append(self)
    
    @classmethod
    def get_value(cls):
        return f"Voter age should greater than : {cls.voter_age}"
    
    @classmethod
    def get_instance_count(cls):
        return f"Number of instances: {len(cls.list_of_instances)}"
    
    @staticmethod
    def my_static_method_add(age):
        return age>=18
    
    
obj1 = MyClass(23)
obj2 = MyClass(17)

print(MyClass.get_value())
print(MyClass.get_instance_count())

res = MyClass.my_static_method_add(23)
print("Age criteria satisfied :", res)