
def sentence_intersection(string1,string2):
    words1 = string1.split()
    words2 = string2.split()
    intersection = []
    for word in words1:
        if word in words2 and word not in intersection:
            intersection.append(word)
    
    return intersection

string1 = input("Enter the string1 : ")
string2 = input("Enter the string2 : ")
print(sentence_intersection(string1,string2))  