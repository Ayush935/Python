
def capitalize_sentence(string):
    """Capitalizes the first letter of each sentence in a string."""
    sentences = string.split('. ')
    capitalized_sentences = [sentence.capitalize() for sentence in sentences]
    return '. '.join(capitalized_sentences)

string = input("Enter the string : ")
print(capitalize_sentence(string))  