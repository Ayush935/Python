def longest_unique_substring(string):
    
    if len(string) == 0:
        return 0
    elif len(string) == 1:
        return string
    else:
        max_length = 0
        max_substring = ""
        for i in range(len(string)):
            for j in range (i+1, len(string)+1):
                substring = string[i:j]
                if len(substring) == len(set(substring)) and len(substring) > max_length:
                    max_length = len(substring)
                    max_substring = substring
                    
        return max_substring
    
string = input("Enter the string : ")
print("The longest unique substring is : ", longest_unique_substring(string))