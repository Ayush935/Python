
def merge_dictionary(dict1,dict2):
    dict = dict1
    dict.update(dict2)
    return dict

dict1 = {"name":"Ayush","height" : 10}
dict2 = {"height": 20,"city" : "Mumbai"}
print(merge_dictionary(dict1,dict2))

