def is_anagram(sentence):
    #is_pangram(sentence) that checks if a sentence is a pangram and also returns any missing letters.
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    sentence = sentence.lower()
    missing_letters = ""
    for letter in alphabet:
        if letter not in sentence:
            missing_letters += letter
    return missing_letters

sentence = "The quick"
print("Anagram : ", is_anagram(sentence))

