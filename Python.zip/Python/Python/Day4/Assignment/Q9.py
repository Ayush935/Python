def frequency_counter(lst):
    #`frequency_counter(lst)` that returns a dictionary with each unique element in the list as a key and its frequency as the value.
    frequency_dict = {}
    for item in lst:
        if item in frequency_dict:
            frequency_dict[item] += 1
        else:
            frequency_dict[item] = 1
    return frequency_dict

lst = {1,2,3,4,2,3,4}
print(frequency_counter(lst))
