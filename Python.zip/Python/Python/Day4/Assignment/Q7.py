def reverse(dict):
    #`reverse_dict(d)` that takes a dictionary and returns a new dictionary with keys and values swapped.
    return {v: k for k, v in dict.items()}

dict = {"name":"Ayush","Roll_no":456}
print(reverse(dict))  