def compress_string(string):
   
    compressed = ""
    count = 1
    for i in range(len(string)):
        if i == len(string) - 1 or string[i] != string[i + 1]:
            compressed += string[i] + str(count)
            count = 1
        else:
            count += 1
    return compressed

string = "AAABBBCCCDDDD"
print(compress_string(string))  
