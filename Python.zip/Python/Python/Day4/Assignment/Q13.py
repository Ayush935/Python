def is_valid_word_ladder(words):
    
    if len(words) < 2:
        return False
    for i in range(len(words)-1):
        if len(words[i]) != len(words[i+1]):
            return False
    diff = 0
    for j in range(len(words[i])):
        if words[i][j] != words[i+1][j]:
            diff += 1
    if diff > 1:
        return False
    return True

words = ["cat", "bat", "bit", "gig"]
print(f"{words} : ",is_valid_word_ladder(words))  # Output: True
            
        
