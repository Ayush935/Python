def is_subset(set1,set2):
    #is_subset(set1, set2)` that checks if one set is a subset of another.
    return set1.issubset(set2)

set1 = {1, 2, 3, 4}
set2 = {1, 2, 3, 4, 5, 6}
print(is_subset(set1, set2))  