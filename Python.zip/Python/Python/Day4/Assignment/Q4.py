def common_keys(dict1,dict2):
    
    return [key for key in dict1 if key in dict2]

dict1 = {"name":"Ayush","Roll_no":345}
dict2 = {"name":"Xyz","Id_no":345,"Branch":"CSE"}
print(common_keys(dict1,dict2))  