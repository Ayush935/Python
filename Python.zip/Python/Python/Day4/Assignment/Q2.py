def most_frequent(numbers):
     
    return max(set(numbers), key = numbers.count)

numbers = [1, 2, 3, 2, 1, 2]
print("Most frequently occured : ", most_frequent(numbers))