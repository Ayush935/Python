def longest_word(sentence):
    
    words = sentence.split()
    longest = max(words, key=len)
    return longest

sentence = input("ENter thr sentence: ")
print("longest word : ", longest_word(sentence))
