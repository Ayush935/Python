def find_pairs(numbers,target):
    #find_pairs(numbers, target)` that finds all unique pairs of integers in a  list that add up to a given target sum
    pairs = []
    for i in range(len(numbers)):
        for j in range(i+1, len(numbers)):
            if numbers[i] + numbers[j] == target:
                pairs.append((numbers[i], numbers[j]))
                
    return pairs

numbers = [1,2,3,4,5]
target = 6
print("Pairs : ",find_pairs(numbers,target))

