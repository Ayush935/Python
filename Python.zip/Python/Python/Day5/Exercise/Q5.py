# python script using the random module to generate a random password of a user-specified length. Ensure the password includes uppercase letters, lowercase letters, numbers and special characters.

import random
import string
 
def generate_password(length):
    letters = string.ascii_letters
    digits = string.digits
    special_chars = string.punctuation
 
    all_chars = letters + digits + special_chars
 
    password = ''.join(random.choice(all_chars) for _ in range(length))
    return password
 
if __name__ == "__main__":
    length = int(input("Enter the desired password length : "))
    password = generate_password(length)
    print("Generated password:", password)