# program to merge the content of multiple text files in a single file. Ask the user for the names of the file to be merged.


def merge_files(file_names, output_file):
    with open(output_file, 'w') as outfile:
        for fname in file_names:
            try:
                with open(fname, 'r') as infile:
                    content = infile.read()
                    outfile.write(content + "\n")  # Add a newline for separation
            except FileNotFoundError:
                print(f"Error: The file '{fname}' does not exist.")
            except Exception as e:
                print(f"An error occurred while processing the file '{fname}': {e}")

def main():
    print("Enter the names of the files to be merged, separated by commas:")
    file_input = input()
    file_names = [name.strip() for name in file_input.split(',')]
    
    output_file = input("Enter the name of the output file (e.g., merged.txt): ")
    
    merge_files(file_names, output_file)
    print(f"Files merged successfully into '{output_file}'.")

if __name__ == "__main__":
    main()