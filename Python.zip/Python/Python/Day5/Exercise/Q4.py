# program that asks the user input a number. id the input is invalid (e.g not a number), catch the exception and ask the user to input it again untill a valid number is entered

def get_valid_number():
    while True:
        user_input = input("Please enter a number: ")
        try:
            
            number = float(user_input)
            return number  
        except ValueError:
           
            print("Invalid input. Please enter a valid number.")


valid_number = get_valid_number()
print(f"You entered a valid number: {valid_number}")