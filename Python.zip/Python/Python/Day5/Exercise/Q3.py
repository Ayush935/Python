# program to validate email addresses from a file. if an email addresses is invalid , log it to an error.txt file with an appropriate message

import re

def is_valid_email(email):
    """Validate the email address using a regex pattern."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_emails(input_file, error_file):
    """Read email addresses from the input file and validate them."""
    with open(input_file, 'r') as infile, open(error_file, 'w') as errfile:
        for line in infile:
            email = line.strip()
            if not is_valid_email(email):
                errfile.write(f"Invalid email address: {email}\n")

if __name__ == "__main__":
    input_file = 'emails.txt'  # Input file containing email addresses
    error_file = 'error.txt'    # Output file for invalid email addresses
    validate_emails(input_file, error_file)
    print("Validation complete. Check 'error.txt' for invalid email addresses.")