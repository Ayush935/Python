# write a program that reads a text file contining a paragrah of text and identifies
# the longest word in the file. if thre are multiple words of same length output them all
# the program should be handle

def find_longest_words(filename):
    try:
        with open(filename, 'r') as file:
            text = file.read()
        
        # Remove punctuation and split into words
        words = text.split()
        cleaned_words = [''.join(char for char in word if char.isalnum()) for word in words]

        # Find the longest length
        max_length = 0
        longest_words = []

        for word in cleaned_words:
            word_length = len(word)
            if word_length > max_length:
                max_length = word_length
                longest_words = [word]
            elif word_length == max_length:
                longest_words.append(word)

        return longest_words

    except FileNotFoundError:
        return "The specified file was not found."
    except Exception as e:
        return f"An error occurred: {e}"

# Example usage
filename = 'Class.txt'  # Replace with your text file name
longest_words = find_longest_words(filename)

if longest_words:
    print("Longest word(s):", ', '.join(longest_words))
else:
    print("No words found in the file.")