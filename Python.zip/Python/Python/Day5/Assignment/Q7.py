class InvalidAgeError(Exception):
    pass

def get_age():
    try:
        age = int(input("Please enter your age: "))
        if age < 0 or age > 150:
            raise InvalidAgeError(f"Invalid age: {age}. Age must be between 0 and 150.")
        print(f"Your age is {age}.")
    except ValueError:
        print("Invalid input. Please enter a valid integer for your age.")
    except InvalidAgeError as e:
        print(e)

if __name__ == "__main__":
    get_age()