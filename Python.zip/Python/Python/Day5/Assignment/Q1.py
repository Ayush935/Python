def calculate_total_cost(input_file, output_file):
    total_cost = 0

    try:
        with open(input_file, 'r') as file:
            for line in file:
                product_info = line.strip().split(',')
                if len(product_info) == 2:
                    price = float(product_info[1].strip())
                    total_cost += price

        with open(output_file, 'w') as file:
            file.write(f"Total Cost: {total_cost}\n")

        print(f"Total cost calculated: {total_cost}")
        print(f"Total cost written to {output_file}")

    except FileNotFoundError:
        print(f"Error: The file {input_file} does not exist.")
    except ValueError:
        print("Error: Could not convert price to float. Please check the input file format.")
    except Exception as e:
        print(f"An error occurred: {e}")

input_file = 'products.txt'
output_file = 'total_cost.txt'
calculate_total_cost(input_file, output_file)