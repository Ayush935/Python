import json
import os

def read_config(file_path):
    required_keys = ['host', 'port', 'username', 'password']
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Configuration file '{file_path}' not found.")
    
    with open(file_path, 'r') as file:
        try:
            config = json.load(file)
        except json.JSONDecodeError:
            raise ValueError("Configuration file is not a valid JSON.")
    
    for key in required_keys:
        if key not in config:
            raise KeyError(f"Missing required configuration key: '{key}'")
    
    return config

config = read_config('config.json')