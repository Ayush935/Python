def count_bytes_in_file(file_path):
    total_bytes = 0
    chunk_size = 1024

    try:
        with open(file_path, 'rb') as file:
            while True:
                chunk = file.read(chunk_size)
                if not chunk:
                    break
                total_bytes += len(chunk)

    except FileNotFoundError:
        print(f"The file '{file_path}' does not exist.")
        return None
    except IOError as e:
        print(f"An error occurred while reading the file: {e}")
        return None

    return total_bytes

file_path = '/home/kpit/Desktop/Python/Python/Day5/Assignment/first.txt'
total_bytes = count_bytes_in_file(file_path)

if total_bytes is not None:
    print(f"Total number of bytes in the file: {total_bytes}")