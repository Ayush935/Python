def reverse_lines(input_file, output_file):
    with open(input_file, 'r') as infile:
        lines = infile.readlines()
    with open(output_file, 'w') as outfile:
        for line in reversed(lines):
            outfile.write(line)

input_filename = 'first.txt'
output_filename = 'reverse.txt'
reverse_lines(input_filename, output_filename)