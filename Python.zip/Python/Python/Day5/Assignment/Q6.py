def divide_numbers_from_file(filename):
    try:
        with open(filename, 'r') as file:
            for line in file:
                line = line.strip()
                if not line:
                    raise ValueError("Missing numbers")
                numbers = line.split(',')
                if len(numbers) != 2:
                    raise ValueError("Missing numbers")
                num1, num2 = map(float, numbers)
                result = num1 / num2
                print(f"{num1} / {num2} = {result}")
    except ValueError as ve:
        print(ve)
    except ZeroDivisionError:
        print("Division by zero.")
    except FileNotFoundError:
        print("File not found.")
        
divide_numbers_from_file('numbers.txt')