def fibonacci(n):
    fib_sequence = []
    a, b = 0, 1
    for _ in range(n):
        fib_sequence.append(a)
        a, b = b, a + b
    return fib_sequence

num_lines = 10
fib_numbers = fibonacci(num_lines)

with open('fibonacci.txt', 'w') as f:
    for number in fib_numbers:
        f.write(f"{number}\n")

print("The first 10 lines of the Fibonacci sequence have been written to 'fibonacci.txt'.")