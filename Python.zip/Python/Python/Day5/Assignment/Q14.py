from datetime import datetime, timedelta

def count_weekdays(start_date, end_date):
    if start_date > end_date:
        start_date, end_date = end_date, start_date
    weekday_count = 0
    current_date = start_date
    while current_date <= end_date:
        if current_date.weekday() < 5:
            weekday_count += 1
        current_date += timedelta(days=1)
    return weekday_count

def main():
    start_date_str = input("Enter the start date (YYYY-MM-DD): ")
    end_date_str = input("Enter the end date (YYYY-MM-DD): ")
    try:
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d")
    except ValueError:
        print("Invalid date format. Please enter dates in YYYY-MM-DD format.")
        return
    weekdays = count_weekdays(start_date, end_date)
    print(f"The number of weekdays between {start_date.date()} and {end_date.date()} is: {weekdays}")

if __name__ == "__main__":
    main()