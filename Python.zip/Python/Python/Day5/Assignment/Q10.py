import urllib.request

def check_urls(file_path):
    with open(file_path, 'r') as file:
        urls = file.readlines()
    
    for url in urls:
        url = url.strip()
        try:
            response = urllib.request.urlopen(url)
            print(f"Connected to {url} with status code: {response.getcode()}")
        except Exception as e:
            print(f"Failed to connect to {url}: {e}")

check_urls('urls.txt')