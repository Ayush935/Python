import os

def count_files_and_folders(directory):
    file_count = 0
    folder_count = 0
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        if os.path.isfile(item_path):
            file_count += 1
        elif os.path.isdir(item_path):
            folder_count += 1
    return file_count, folder_count

def write_results_to_file(file_count, folder_count, output_file):
    with open(output_file, 'w') as f:
        f.write(f'Number of files: {file_count}\n')
        f.write(f'Number of folders: {folder_count}\n')

def main():
    directory = input("Enter the directory path: ")
    if not os.path.isdir(directory):
        print("The provided path is not a valid directory.")
        return
    file_count, folder_count = count_files_and_folders(directory)
    output_file = 'directory_count.txt'
    write_results_to_file(file_count, folder_count, output_file)
    print(f"Results written to {output_file}")

if __name__ == "__main__":
    main()