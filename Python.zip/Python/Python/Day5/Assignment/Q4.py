import os
from datetime import datetime

def append_or_create_file(filename):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if os.path.exists(filename):
        with open(filename, 'a') as file:
            file.write(f"{timestamp}\n")
        print(f"Appended timestamp to {filename}: {timestamp}")
    else:
        with open(filename, 'w') as file:
            file.write(f"{timestamp}\n")
        print(f"Created new file {filename} with timestamp: {timestamp}")

filename = 'first.txt'
append_or_create_file(filename)