import random

def roll_dice():
    return random.randint(1, 6)

def play_game():
    player1_score = 0
    player2_score = 0
    rounds = 5

    for _ in range(rounds):
        player1_score += roll_dice()
        player2_score += roll_dice()

    if player1_score > player2_score:
        return "Player 1 wins!"
    elif player2_score > player1_score:
        return "Player 2 wins!"
    else:
        return "It's a tie!"

if __name__ == "__main__":
    result = play_game()
    print(result)