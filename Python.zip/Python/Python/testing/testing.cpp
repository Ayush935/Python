
#include <iostream>

int main() {
    std::cout << "Hello, ARM World from C++!" << std::endl;
    return 0;
}
