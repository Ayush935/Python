from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI()

# Task model
class Task(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    completed: bool = False

# In-memory storage for tasks
tasks = []

# Helper function to find a task by ID
def find_task(task_id: int):
    for task in tasks:
        if task.id == task_id:
            return task
    return None

# Create a new task
@app.post("/tasks/", response_model=Task)
def create_task(task: Task):
    if find_task(task.id) is not None:
        raise HTTPException(status_code=400, detail="Task ID already exists")
    tasks.append(task)
    return task

# Read all tasks
@app.get("/tasks/", response_model=List[Task])
def read_tasks():
    return tasks

# Read a specific task by ID
@app.get("/tasks/{task_id}", response_model=Task)
def read_task(task_id: int):
    task = find_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

# Update a task by ID
@app.put("/tasks/{task_id}", response_model=Task)
def update_task(task_id: int, updated_task: Task):
    task = find_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    
    task.title = updated_task.title
    task.description = updated_task.description
    task.completed = updated_task.completed
    return task

# Delete a task by ID
@app.delete("/tasks/{task_id}", response_model=Task)
def delete_task(task_id: int):
    task = find_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    
    tasks.remove(task)
    return task