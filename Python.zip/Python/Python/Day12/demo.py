import openpyxl
import logging
import os
import json
import re
import datetime
 
# Function to find a specific pattern in the ID string
def find_number_pattern(id_str, logger):
    match = re.search(r'_(\w+_\d+)', id_str)
    if match:
        return match.group(1)
    else:
        # Logging Message if the id is not in "_APP_1234" format
        warning_logging(f"ID FORMAT INVALID: {id_str}",logger)
        return None
 
# Function to check the status of a list of steps
def check_status(list_status):
    for status in list_status:
        # If even one step fails the test case falied
        if status.get('result') == "FAILED":
            return "Fail"
    return "Pass"
 
# Function to find the objective from a string
def find_objective(str, logger):
    pattern = r' - (.*?) [@#]'
    match = re.search(pattern, str)
    if match:
        return match.group(1)
    else:
        # Logging if objective in json is not in valid form
        warning_logging(f"JSON OBJECTIVE INVALID: {str}", logger)
        return None
   
def setup_logging(sheet_name):
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    sheet_log_dir = os.path.join(logs_dir, sheet_name)
    os.makedirs(sheet_log_dir, exist_ok=True)  # Create directory for the sheet
    log_file_name = f"{current_time}.log"
    log_file_path = os.path.join(sheet_log_dir, log_file_name)
   
    # Create a custom logger for each sheet
    logger = logging.getLogger(sheet_name)
    logger.setLevel(logging.DEBUG)
 
    # Create file handler
    file_handler = logging.FileHandler(log_file_path)
    file_handler.setLevel(logging.DEBUG)
 
    # Create formatter and add it to the handler
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
 
    # Clear existing handlers and add the new handler
    if logger.hasHandlers():
        logger.handlers.clear()
    logger.addHandler(file_handler)
 
    return logger
 
# Function to read JSON files and populate the ID dictionary
def read_json(json_dir, id_dict):
    json_logger=setup_logging('json_logs')
    for json_file in os.listdir(json_dir):
        if json_file.endswith('.json'):
            try:
                with open(os.path.join(json_dir, json_file), 'r') as file:
                    data = json.load(file)
                    for result in data.get('results'):
                        id_value = find_number_pattern(result.get('scenarioName'), json_logger)
                        id_objective = find_objective(result.get('scenarioName'), json_logger)
                        result_value = check_status(result.get('steps'))
                        if id_value is not None and id_objective is not None:
                            id_dict[id_value] = {'objective': id_objective, 'result': result_value, 'scenario_name': result.get('scenarioName')}
            except:
                print()
    print(id_dict)
 
# Function to categorize elements based on their prefixes
def categorize_elements(id_map):
    prefix_map = {
        'ASYNC_': 'ASYNC',
        'APP_': 'APP_CONTROLLER',
        'BENCH_': 'BENCH_CONTROLLER',
        'LIC_': 'LICENSE',
        'DB_': 'DATABASE',
        'VTP_': 'VTP_CONTROLLER',
        'CLOUD_': 'CLOUD_ORCHESTRATION',
        'Q_': 'QUEUE',
        'JS_': 'JOB_STATUS',
        'CM_': 'CODE_METER',
        'OS_': 'OBJECT_STORAGE'
    }
    sheet_dict = {key: [] for key in prefix_map.values()}
 
    for key, value in id_map.items():
        for prefix, category in prefix_map.items():
            if key.startswith(prefix):
                sheet_dict[category].append((key, value))
                break
    return sheet_dict
 
# Function to search for objectives in the Excel sheet
def search_objective(sheet, row, column, json_objective, json_id, logger):
    excel_objective = sheet.cell(row=row, column=column).value
    for cell in sheet.iter_rows(min_row=4, min_col=column, max_col=column):
        cell = cell[0]
        if cell.value is None:
            break
        curr_objective = cell.value
        curr_id = sheet.cell(row=cell.row, column=1).value
        if curr_objective.strip() == excel_objective.strip() and find_number_pattern(curr_id, logger) != json_id:
            warning_logging(f"EXCEL ERROR:\nObjective: {excel_objective}\nDuplicated in Id: {curr_id}, {sheet.cell(row=row, column=1).value}",logger)
        if curr_objective.strip() == json_objective.strip():
            warning_logging(f"MISMATCH ERROR:\nObjective: {json_objective}\nJSON Id: {sheet.cell(row=row, column=1).value}, Excel Id: {curr_id}", logger)
    warning_logging(f"JSON OBJECTIVE NOT MATCH IN EXCEL:\nExcel Data\nId: {sheet.cell(row=row, column=1).value}, objective: {excel_objective})\nJSON Data:\nID: KINETO_{json_id}, Objective: {json_objective}", logger)
 
# Function to update the Excel sheet with the JSON data
def update_sheet(file_path, sheet_name, value):
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook[sheet_name]
    sheet_logger=setup_logging(sheet_name)
    result_column = None
    objective_column = None
    automated_column = None
    for cell in sheet[3]:
        if cell.value == 'Results':
            result_column = cell.column
        elif cell.value == 'Objective':
            objective_column = cell.column
        elif cell.value == 'Automated':
            automated_column = cell.column
 
    for cell in sheet.iter_rows(min_row=4, min_col=1, max_col=1):
        cell = cell[0]
        if cell.value is None:
            break
        id = find_number_pattern(cell.value,sheet_logger)
        temp = dict(value)
        if id in temp:
            if (temp[id]['objective']).strip() == (sheet.cell(row=cell.row, column=objective_column).value).strip():
                sheet.cell(row=cell.row, column=result_column, value=temp[id]['result'])
                sheet.cell(row=cell.row, column=automated_column, value='Yes')
            else:
                search_objective(sheet, cell.row, objective_column, temp[id]['objective'], id, sheet_logger)
        else:
            sheet.cell(row=cell.row, column=result_column, value='Not Tested')
            sheet.cell(row=cell.row, column=automated_column, value='No')
   
    workbook.save(file_path)
 
# Function to log warnings to make sure no log is repeated
def warning_logging(message,logger):
    if message not in error_log:
        logger.warning(message)
        error_log.add(message)
 
# Initialize error log and logging configuration
error_log = set()
script_dir = os.path.dirname(os.path.abspath(__file__))
logs_dir = os.path.join(script_dir, 'excel_logs')
 
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)
 
# Directory containing JSON files
json_directory = r'C:\Users\shubhamd11\Downloads\target\target\zerocode-test-reports'
id_dict = {}
read_json(json_directory, id_dict)
 
# Path to the Excel file
file_path = r'C:\Users\shubhamd11\Downloads\target\target\MasterSheet_API 5.xlsx'
 
# Update the Excel sheet with categorized elements
for key, value in categorize_elements(id_dict).items():
    if len(value) != 0:
        update_sheet(file_path, key, value)
 