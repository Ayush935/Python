from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Define the SQLite database
DATABASE_URL = "sqlite:///users.db"

# Create a new SQLAlchemy engine
engine = create_engine(DATABASE_URL, echo=True)

# Create a base class for declarative models
Base = declarative_base()

# Define the User model
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)

# Create the table in the database
Base.metadata.create_all(engine)

# Create a new session
Session = sessionmaker(bind=engine)
session = Session()

# Insert three records into the User table
user1 = User(name='Alice', email='alice@example.com')
user2 = User(name='Bob', email='bob@example.com')
user3 = User(name='Charlie', email='charlie@example.com')

# Add the users to the session
session.add(user1)
session.add(user2)
session.add(user3)

# Commit the session to save the records
session.commit()

# Query all records from the User table
users = session.query(User).all()

# Print the records
for user in users:
    print(f'ID: {user.id}, Name: {user.name}, Email: {user.email}')

# Close the session
session.close()