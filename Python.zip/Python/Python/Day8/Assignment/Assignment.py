
# def my_decorator(func):
#     def wrapper(*args,**kwargs):
#         list=func(*args,**kwargs)
#         for i in range(len(list)):
#             list[i]+=1
#         return list
#     return wrapper
        
        
        
# @my_decorator
# def function(list):
#     return list

# list = [1,2,3,4,5]
# print(function(list))


# def is_prime(num):
#     for i in range(2,num):
#         if num % i == 0:
#             return False
#     return True

# def prime_numbers():
#     num = 2
#     while True:
#         if is_prime(num):
#             yield num
#         num+=1
        
# if __name__ == "__main__":
#     gen = prime_numbers()
#     for _ in range(10):
#         print(next(gen))

# def tail_f(filename):
#     with open (filename,'r') as f:
#         lines = f.readlines()
#         lines = lines[-2:]
#         for line in lines:
#             yield lines

# print(next(tail_f('file.txt')))
            
# class PowersOfTwo:
#     def __init__(self, max_value):
#         self.max_value = max_value
#         self.current = 1  

#     def __iter__(self):
#         return self

#     def __next__(self):
#         if self.current > self.max_value:
#             raise StopIteration
#         result = self.current
#         self.current *= 2  
#         return result


# if __name__ == "__main__":
#     max_value = 100
#     powers_of_two = PowersOfTwo(max_value)

#     for power in powers_of_two:
#         print(power)

# class PascalTriangleIterator:
#     def __init__(self, n):
#         self.n = n  
#         self.current_row = 0  

#     def __iter__(self):
#         return self

#     def __next__(self):
#         if self.current_row >= self.n:
#             raise StopIteration  
        
     
#         row = self._generate_row(self.current_row)
#         self.current_row += 1 
#         return row

#     def _generate_row(self, row_index):
#         """Generate the row at the given index in Pascal's Triangle."""
#         row = [1]  
#         if row_index == 0:
#             return row
        
#         for k in range(1, row_index + 1):
          
#             next_value = row[k - 1] * (row_index - k + 1) // k
#             row.append(next_value)
        
#         return row


# n = 5  
# pascal_iterator = PascalTriangleIterator(n)

# for row in pascal_iterator:
#     print(row)

def type_validator(arg_types):
    def decorator(func):
        def wrapper(*args, **kwargs):
           
            all_args = {**dict(zip(func.__code__.co_varnames, args)), **kwargs}
            
            for arg_name, expected_type in arg_types.items():
                if arg_name in all_args:
                    actual_type = type(all_args[arg_name])
                    if actual_type is not expected_type:
                        raise TypeError(f"Argument '{arg_name}' must be of type {expected_type.__name__}, "
                                        f"but got {actual_type.__name__}.")
            return func(*args, **kwargs)
        return wrapper
    return decorator


@type_validator({'a': int, 'b': str})
def example_function(a, b):
    print(f"a: {a}, b: {b}")


example_function(10, "Hello")


try:
    example_function("10", "Hello")  
except TypeError as e:
    print(e)

try:
    example_function(10, 20)  
except TypeError as e:
    print(e)