"""
Write a decorator that ensures a function can only be called a specific number of times
"""

def limits(counts):
    def my_decorator(func):
        def wrapper(*args, **kwargs):
            if wrapper.call_count < counts:
                wrapper.call_count += 1
                return func(*args, **kwargs)
            else:
                print("limit limit limit")
        wrapper.call_count = 0
        return wrapper
    return my_decorator

@limits(3)
def function():
    print("Hello world")
    
if __name__ == "__main__":
    for i in range(5):
        try:
            function()
        except Exception as e:
            print(e)
    
    
