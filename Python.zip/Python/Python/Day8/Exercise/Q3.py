"""
Write a custom generator-based context manager for file handling, use f.open(), f.close().

"""

from contextlib import contextmanager

@contextmanager
def handle_file(filename,mode):
    try:
        file = open(filename,mode)
        yield file
    finally:
        file.close()

with handle_file("file.txt",'w') as f:
    f.write("Hello world")
    
with handle_file("file.txt",'r') as f:
    print(f.read())
    