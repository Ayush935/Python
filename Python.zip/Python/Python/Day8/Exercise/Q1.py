""" 
Write a decorator that logs the execution time of a function.

"""

def my_decorator(func):
    def wrapper():
        import time
        start_time = time.time()
        func()
        end_time = time.time()
        print(f"Function {func.__name__} executed in {end_time - start_time} seconds")
    return wrapper

@my_decorator
def function():
    import time
    time.sleep(2)
    print("Hello world")
    
function()  