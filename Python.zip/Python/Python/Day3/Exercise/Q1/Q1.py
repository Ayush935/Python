

def is_palindrome(string):
    n_string = ''.join(string.lower() for string in string if string.isalnum())
    checker_string = n_string[::-1]
    return n_string == checker_string

string = input("Enter the string : ")
if is_palindrome(string):
    print("The string is palindrome")
else:
    print("The string is not palindrome")
    
    