
def is_anagram(string_one,string_two):
    return sorted(string_one)==sorted(string_two)

string_one = input("Enter the first string : ")
string_two = input("Enter the second string : ")
if is_anagram(string_one,string_two):
    print("The strings are anagram")
else:
    print("The strings are not anagram")