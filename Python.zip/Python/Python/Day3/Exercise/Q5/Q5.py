
def generate_pythagoreantriplet(n):
    for a in range(1,n):
        for b in range(a,n):
            c = n - a - b
            if c>0 and a**2 + b**2 == c**2:
                return (a,b,c)
            
    
    return None


num = int(input("Enter the number : "))
result = generate_pythagoreantriplet(num)
print(f"Pythagorean triplet for {num} is ", result) 