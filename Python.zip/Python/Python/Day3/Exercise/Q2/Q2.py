
def fibonacci_term(term):
    if term==0:
        return 0
    elif term==1:
        return 1
    
    first_term = 0
    second_term = 1
    for i in range(term):
        first_term, second_term = second_term, first_term + second_term
        
    return second_term

num = int(input("Enter the term number : "))
print(f"The {num} th term of the Fibonacci sequence is : ",fibonacci_term(num))
    