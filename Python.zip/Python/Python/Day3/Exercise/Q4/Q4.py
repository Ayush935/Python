
def power(base,exponent):
    if exponent<0:
        return 1/power(base,-exponent)
    elif exponent==0:
        return 1
    
    result =1
    
    for i in range(exponent):
        result *= base
    
    return result

base = int(input("Enter the base : "))
exponent = int(input("Enter the exponent : "))
print("The result is : ",power(base,exponent))