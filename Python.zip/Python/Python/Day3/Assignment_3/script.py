
"""
def sum_of_squares(start,end):
    return sum(i**2 for i in range(start,end+1) if i%2==0)

start = int(input("Enter the starting number : "))
end = int(input("Enter the ending number : "))
print("Sum of square : ",sum_of_squares(start,end))

"""

"""
def count_words(string):
    return len(string.split())

string = input("Enter thr string : ")
print("Number of words : ",count_words(string))

"""

"""
def longest_word_in_string(string):
    return max(string.split(),key=len)

string = input("Enter the string : ")
print("Longest word in the string : ",longest_word_in_string(string))

"""

"""
def least_common_multiple(num1,num2):
    def gcd(a,b):
        while b:
            a,b = b,a%b
        return a
    return abs(num1*num2)//gcd(num1,num2)

num1 = int(input("Enter the first number : "))
num2 = int(input("Enter the second number : "))
print("Least common divisor is : ",least_common_multiple(num1,num2))

"""

"""
def generate_multiplication_table(num):
    for i in range(1,11):
        print(f"{num} * {i} = {num*i}")
        
num = int(input("Enter the number : "))
generate_multiplication_table(num)

"""

"""
def custom_sort(numbers):
    n = len(numbers)
    
    for i in range(n):
        swapped = False
        for j in range(0,n-i-1):
            if numbers[j] > numbers[j+1]:
                numbers[j],numbers[j+1] = numbers[j+1],numbers[j]
                swapped = True
            
        if not swapped:
            break
        
    return numbers

user_input = input("Enter the list of numbers : ")
numbers = list(map(int,user_input.split()))
print("Sorted list : ",custom_sort(numbers))


"""

"""def addition(num1,num2):
    return num1+num2

def subtraction(num1,num2):
    return num1-num2

def multiplication(num1,num2):
    return num1*num2

def division(num1,num2):
    return num1/num2

def calci():
    print(" Select Operation to perform ")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    
    user_choice = input("Enter choice 1/2/3/4 : ")
    
    if user_choice in [1,2,3,4]:
        num1 = float(input("Enter first number : "))
        num2 = float(input("Enter second number: "))
        
        if user_choice == '1':
            print(f"{num1} + {num2} = {addition(num1, num2)}")
        elif user_choice == '2':
            print(f"{num1} - {num2} = {subtraction(num1, num2)}")
        elif user_choice == '3':
            print(f"{num1} * {num2} = {multiplication(num1, num2)}")
        elif user_choice == '4':
            print(f"{num1} / {num2} = {division(num1, num2)}")
    else:
        print("Invalid input! Please select a valid operation.")

# Run the calculator
calci()

"""

"""
def sum_odd_fibonacci(num):
    a, b = 0,1
    sum = 0
    for i in range(num):
        if a % 2 != 0:
            sum += a
        a, b = b, a +b
            
    return sum

num = int(input("Enter the number : "))
print("Sum of odd fibonacci numbers is :",sum_odd_fibonacci(num))

"""

"""
def calculate_interest(principal,rate,time):
    return (principal*rate*time)/100

principal = float(input("Enter the principal amount : "))
rate = float(input("Enter the rate of interest : "))
time = float(input("Enter the time period : "))
print("Total amount : ",principal+calculate_interest(principal,rate,time))

"""

def atm_stimulation(balance,transaction_type,amount):
    if transaction_type == "withdrawal":
        if balance >= amount:
            balance -= amount
            print("Withdrawal successful. Remaining balance is : ",balance)
        else:
            print("Insufficient balance")
            
    elif transaction_type == "deposit":
        balance += amount
        print("Deposit successful. New balance is : ",balance)
        
    elif transaction_type == "balance":
        print("Current balance is : ",balance)
        
    else:
        print("Invalid transaction type")
        
    return balance
        
def stimulate_atm():
    balance = float(input("Enter the initial balance : "))
    while True:  
        print("1. Withdrawal")
        print("2. Deposit")
        print("3. Balance")
        print("4. Exit")  

        choice = input("Enter choice in 1/2/3/4: ")

        if choice == '1':
            amount = float(input("Enter the amount to withdraw: "))
            if amount > 0:
                balance = atm_stimulation(balance, "withdrawal", amount)
            else:
                print("Please enter a valid amount.")
        
        elif choice == '2':
            amount = float(input("Enter the amount to deposit: "))
            if amount > 0:
                balance = atm_stimulation(balance, "deposit", amount)
            else:
                print("Please enter a valid amount.")
        
        elif choice == '3':
            balance = atm_stimulation(balance, "balance", 0)
        
        elif choice == '4':
            print("Thank you for using the ATM. Goodbye!")
            break  
        
        else:
            print("Invalid choice. Please try again.")

stimulate_atm()