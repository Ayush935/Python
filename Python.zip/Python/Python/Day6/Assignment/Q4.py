from dotenv import load_dotenv
import os

def check_use_db():
    load_dotenv() 
    use_db = os.getenv("USE_DB")
    if use_db is None:
        return False
    return use_db.lower() == "true"

print(check_use_db())  