from PIL import Image

def resize_image(image_path, new_size):
    img = Image.open(image_path)
    img = img.resize(new_size)
    img.save("resized_image.png")


resize_image("/home/kpit/Pictures/Screenshot from 2024-11-25 15-11-59.png", (800, 600))  