from datetime import datetime

class Person:
    def __init__(self, firstname, lastname, dob):
        self.firstname = firstname
        self.lastname = lastname
        self.dob = datetime.strptime(dob, "%Y-%m-%d")

    def fullname(self):
        return f"{self.firstname} {self.lastname}"

    def age(self):
        today = datetime.today()
        age = today.year - self.dob.year
        if today.month < self.dob.month or (today.month == self.dob.month and today.day < self.dob.day):
            age -= 1
        return age


person = Person("Ayush", "Mahakulkar", "1990-02-28")
print(person.fullname()) 
print(person.age())  