import os

def list_files_and_folders(directory):
    return os.listdir(directory)

# Example usage:
print(list_files_and_folders("/home/kpit/Desktop/Python/Python/Day5/Assignment/calculator"))