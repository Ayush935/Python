import requests
from bs4 import BeautifulSoup


url = 'https://www.google.com'  


response = requests.get(url)

if response.status_code == 200:
   
    soup = BeautifulSoup(response.content, 'html.parser')
    
   
    title = soup.title.string if soup.title else 'No title found'
 
    print(f'Title of the page: {title}')
else:
    print(f'Failed to retrieve the page. Status code: {response.status_code}')