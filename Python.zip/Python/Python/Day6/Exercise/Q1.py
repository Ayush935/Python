import requests

url = 'http://dummyjson.com/test'
response = requests.get(url)
print(response.text)  