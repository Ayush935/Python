import pandas as pd

file_path = '/home/kpit/Downloads/data.csv'
data = pd.read_csv(file_path)

# print(data.columns)

data['Calories'].fillna(249,inplace=True)

new_data = data[data['Calories']>250]

average_max_pulse = new_data['Maxpulse'].mean()

print(f"print average max pulse: {average_max_pulse}")  