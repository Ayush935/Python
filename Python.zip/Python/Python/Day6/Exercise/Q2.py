import requests


url = 'https://dummyjson.com/products'


response = requests.get(url)


if response.status_code == 200:
   
    data = response.json()
    
   
    product_titles = [product['title'] for product in data['products']]
    
  
    for title in product_titles:
        print(title)
else:
    print(f"Failed to retrieve data: {response.status_code}")