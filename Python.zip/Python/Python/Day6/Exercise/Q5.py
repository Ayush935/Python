import requests
from bs4 import BeautifulSoup
import os


def create_directory(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)


def download_image(url, folder):
    try:
        response = requests.get(url)
        if response.status_code == 200:
           
            image_name = url.split('/')[-1]
           
            with open(os.path.join(folder, image_name), 'wb') as f:
                f.write(response.content)
            print(f'Downloaded: {image_name}')
        else:
            print(f'Failed to retrieve image from {url}')
    except Exception as e:
        print(f'Error downloading {url}: {e}')


def scrape_images(url, folder):
    
    response = requests.get(url)
    if response.status_code == 200:
      
        soup = BeautifulSoup(response.content, 'html.parser')

        img_tags = soup.find_all('img')
        
    
        create_directory(folder)

       
        for img in img_tags:
            img_url = img.get('src')
            if img_url:
               
                if not img_url.startswith('http'):
                    img_url = requests.compat.urljoin(url, img_url)
                download_image(img_url, folder)
    else:
        print(f'Failed to retrieve webpage: {url}')

if __name__ == '__main__':
    target_url = 'https://www.google.com'  
    download_folder = 'downloaded_images'
    scrape_images(target_url, download_folder)